﻿/**
 * @class L.Draw.Polyline
 * @aka Draw.Polyline
 * @inherits L.Draw.Feature
 */ 
L.DrawExt = L.DrawExt|| {};
L.DrawExt.PolylineLimitPoint = L.Control.PolylineMeasure.extend({});
	