﻿$(document).ready(function () {
    $('.dou-left-menu > .dou-menu > .btn').on('click', function () {
        $('.dou-menu').toggleClass('collapsed');
    });
});